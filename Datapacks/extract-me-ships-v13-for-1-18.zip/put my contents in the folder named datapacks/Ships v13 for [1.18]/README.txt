
    "Ships out on the oceans" - Datapack made by Ercerus
  --------------------------------------------------------


Current Version: 13


Official Website and bug report:
https://www.planetminecraft.com/mod/ships-out-on-the-oceans/


For more creations made by me visit:
https://www.planetminecraft.com/member/ercerus/submissions/?morder=order_latest



The provided websites are the only trusworthy source for this datapack. If you
downloaded this datapack somewhere else delete it and redownload it from the 
official webiste. Ditributing this datapack is not allowed. If you want to publish
something which contains this datapack you must credit me and provide an easily 
accessible link to the datapacks official website. I would also appreciate it, if
you would send me a message if you used my datapck as part of your own creation.

